package com.example.uber.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.uber.model.Vehicle;
import com.example.uber.service.VehicleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/vehicles")
public class VehicleController {
    private final VehicleService service;

    public VehicleController(VehicleService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Vehicle addVehicle(@Valid @RequestBody Vehicle v) { return service.addVehicle(v); }

    @GetMapping("/{id}")
    public Vehicle getVehicle(@PathVariable Long id) { return service.getVehicle(id); }

    @PutMapping("/{id}")
    public Vehicle updateVehicle(@PathVariable Long id, @Valid @RequestBody Vehicle v) {
        return service.updateVehicle(id, v);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteVehicle(@PathVariable Long id) { service.deleteVehicle(id); }

    @GetMapping
    public List<Vehicle> listVehicles() { return service.listVehicles(); }
}


package com.example.uber.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.uber.exception.ResourceNotFoundException;
import com.example.uber.model.Driver;
import com.example.uber.repo.DriverRepository;

@Service
@Transactional
public class DriverService {
    private final DriverRepository repo;

    public DriverService(DriverRepository repo) { this.repo = repo; }

    public Driver addDriver(Driver d) { return repo.save(d); }

    public Driver getDriver(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Driver not found: " + id));
    }

    public Driver updateDriver(Long id, Driver updated) {
        Driver existing = getDriver(id);
        existing.setName(updated.getName());
        existing.setLicenseNumber(updated.getLicenseNumber());
        existing.setLicenseClass(updated.getLicenseClass());
        existing.setHireDate(updated.getHireDate());
        existing.setStatus(updated.getStatus());
        return repo.save(existing);
    }

    public void deleteDriver(Long id) { repo.delete(getDriver(id)); }

    public List<Driver> listDrivers() { return repo.findAll(); }
}

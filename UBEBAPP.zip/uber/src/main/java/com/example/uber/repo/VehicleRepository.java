package com.example.uber.repo;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.uber.model.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    Optional<Vehicle> findByVin(String vin);
}

package com.example.uber.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.uber.model.TripEvent;
import com.example.uber.service.TripEventService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/events")
public class TripEventController {
    private final TripEventService service;

    public TripEventController(TripEventService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TripEvent recordEvent(@Valid @RequestBody TripEvent e) { return service.recordEvent(e); }

    @GetMapping("/{id}")
    public TripEvent getEventDetails(@PathVariable Long id) { return service.getEvent(id); }

    @GetMapping("/vehicle/{vehicleId}")
    public List<TripEvent> listEventsForVehicle(@PathVariable Long vehicleId) {
        return service.listEventsForVehicle(vehicleId);
    }
}

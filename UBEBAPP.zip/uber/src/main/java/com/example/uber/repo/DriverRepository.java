package com.example.uber.repo;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.uber.model.Driver;

public interface DriverRepository extends JpaRepository<Driver, Long> {
    Optional<Driver> findByLicenseNumber(String licenseNumber);
}


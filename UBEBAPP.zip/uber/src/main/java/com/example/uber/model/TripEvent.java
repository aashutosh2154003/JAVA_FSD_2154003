package com.example.uber.model;



import java.time.Instant;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "trip_events", indexes = {
    @Index(name = "idx_vehicle", columnList = "vehicleId"),
    @Index(name = "idx_driver", columnList = "driverId"),
    @Index(name = "idx_event_ts", columnList = "eventTimestamp")
})
public class TripEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eventId;

    @NotNull
    private Long vehicleId;

    @NotNull
    private Long driverId;

    @Enumerated(EnumType.STRING)
    @Column(length = 10, nullable = false)
    private EventType eventType;

    public enum EventType { START, STOP, IDLE, GEOFENCE }

    @NotNull
    private Instant eventTimestamp;

    @DecimalMin(value = "-90.0") @DecimalMax(value = "90.0")
    private double latitude;

    @DecimalMin(value = "-180.0") @DecimalMax(value = "180.0")
    private double longitude;

    @PositiveOrZero
    private double speedKph;

    @Size(max = 255)
    private String notes;

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Long getDriverId() {
		return driverId;
	}

	public void setDriverId(Long driverId) {
		this.driverId = driverId;
	}

	public EventType getEventType() {
		return eventType;
	}

	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	public Instant getEventTimestamp() {
		return eventTimestamp;
	}

	public void setEventTimestamp(Instant eventTimestamp) {
		this.eventTimestamp = eventTimestamp;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getSpeedKph() {
		return speedKph;
	}

	public void setSpeedKph(double speedKph) {
		this.speedKph = speedKph;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

    // getters and setters
}


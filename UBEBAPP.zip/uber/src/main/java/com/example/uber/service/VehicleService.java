package com.example.uber.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.uber.exception.ResourceNotFoundException;
import com.example.uber.model.Vehicle;
import com.example.uber.repo.VehicleRepository;

@Service
@Transactional
public class VehicleService {
    private final VehicleRepository repo;

    public VehicleService(VehicleRepository repo) { this.repo = repo; }

    public Vehicle addVehicle(Vehicle v) { return repo.save(v); }

    public Vehicle getVehicle(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + id));
    }

    public Vehicle updateVehicle(Long id, Vehicle updated) {
        Vehicle existing = getVehicle(id);
        existing.setVin(updated.getVin());
        existing.setMake(updated.getMake());
        existing.setModel(updated.getModel());
        existing.setYear(updated.getYear());
        existing.setStatus(updated.getStatus());
        return repo.save(existing);
    }

    public void deleteVehicle(Long id) { repo.delete(getVehicle(id)); }

    public List<Vehicle> listVehicles() { return repo.findAll(); }
}

package com.example.uber.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.uber.model.Driver;
import com.example.uber.service.DriverService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/drivers")
public class DriverController {
    private final DriverService service;

    public DriverController(DriverService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Driver addDriver(@Valid @RequestBody Driver d) { return service.addDriver(d); }

    @GetMapping("/{id}")
    public Driver getDriver(@PathVariable Long id) { return service.getDriver(id); }

    @PutMapping("/{id}")
    public Driver updateDriver(@PathVariable Long id, @Valid @RequestBody Driver d) {
        return service.updateDriver(id, d);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDriver(@PathVariable Long id) { service.deleteDriver(id); }

    @GetMapping
    public List<Driver> listDrivers() { return service.listDrivers(); }
}


package com.example.uber.repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.uber.model.TripEvent;

public interface TripEventRepository extends JpaRepository<TripEvent, Long> {
    List<TripEvent> findByVehicleIdOrderByEventTimestampDesc(Long vehicleId);
}

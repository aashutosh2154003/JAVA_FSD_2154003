package com.example.uber.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.uber.exception.ResourceNotFoundException;
import com.example.uber.model.TripEvent;
import com.example.uber.repo.DriverRepository;
import com.example.uber.repo.TripEventRepository;
import com.example.uber.repo.VehicleRepository;

@Service
@Transactional
public class TripEventService {
    private final TripEventRepository repo;
    private final VehicleRepository vehicleRepo;
    private final DriverRepository driverRepo;

    public TripEventService(TripEventRepository repo, VehicleRepository vehicleRepo, DriverRepository driverRepo) {
        this.repo = repo; this.vehicleRepo = vehicleRepo; this.driverRepo = driverRepo;
    }

    public TripEvent recordEvent(TripEvent e) {
        vehicleRepo.findById(e.getVehicleId())
            .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + e.getVehicleId()));
        driverRepo.findById(e.getDriverId())
            .orElseThrow(() -> new ResourceNotFoundException("Driver not found: " + e.getDriverId()));
        return repo.save(e);
    }

    public TripEvent getEvent(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Event not found: " + id));
    }

    public List<TripEvent> listEventsForVehicle(Long vehicleId) {
        vehicleRepo.findById(vehicleId)
            .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + vehicleId));
        return repo.findByVehicleIdOrderByEventTimestampDesc(vehicleId);
    }
}


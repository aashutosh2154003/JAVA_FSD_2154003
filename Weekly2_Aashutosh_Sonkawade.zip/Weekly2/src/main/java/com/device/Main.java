package com.device;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.time.LocalDate;

@Configuration
@ComponentScan(basePackages = "com.device")
public class Main {

    private static final String OFF = "OFF";

	@Bean
    public ReportGenerator reportGenerator() {
        return new ReportGenerator(5.0, LocalDate.now()); 
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Main.class);

        
        DeviceController deviceController = context.getBean(DeviceController.class);
        EnergyTracker energyTracker = context.getBean(EnergyTracker.class);
        ReportGenerator reportGenerator = context.getBean(ReportGenerator.class);
        deviceController.setDeviceId("1");
        deviceController.setDeviceName("Fan");
        deviceController.turnOn();
        energyTracker.recordUsage(deviceController.getDeviceId(), 2.5);
        deviceController.turnOff();
        energyTracker.recordUsage(deviceController.getDeviceId(),0.0);
        deviceController.turnOn();
        energyTracker.recordUsage(deviceController.getDeviceId(), 4.0);
        deviceController.turnOff(); //if we comment this line it will go to else loop.
        
       
        if (deviceController.getStatus().equals(OFF)) {
        System.out.println();
        reportGenerator.generateDailyReport();
        reportGenerator.generateAlert();
        context.close();
        }
        else {
        	System.out.println("Device is still ON");
        }
        
        
    }
    
}

package com.device;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.DoubleStream;

@Component
public class EnergyTracker {

    private Map<String, Double> usageData = new HashMap<>();

    @Autowired
    private DeviceController deviceController;

        public void recordUsage(String deviceId, double units) {
        usageData.put(deviceId, usageData.getOrDefault(deviceId, 0.0) + units);
        System.out.println("number :"+deviceId +" device has current units "+units +" kWh");
    }

        public double getTotalUsage() {
            double totalUsage = usageData.values().stream().mapToDouble(Double::doubleValue).sum();
            return totalUsage;
        }

    public Map<String, Double> getUsageData() {
        return usageData;
    }
}

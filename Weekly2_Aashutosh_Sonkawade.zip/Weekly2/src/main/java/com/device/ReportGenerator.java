package com.device;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Component
public class ReportGenerator {

    @Autowired
    private EnergyTracker energyTracker;

    private double threshold;
    private LocalDate reportDate;

    public ReportGenerator(double threshold, LocalDate reportDate) {
        this.threshold = threshold;
        this.reportDate = reportDate;
    }

        public void generateDailyReport() {
        System.out.println("Generating daily report on date of: " + reportDate);
        double totalUsage = energyTracker.getTotalUsage();
        System.out.println("Total energy consumption for today: " + totalUsage + " kWh");
    }

        public void generateAlert() {
        double totalUsage = energyTracker.getTotalUsage();
        if (totalUsage > threshold) {
            System.out.println("ALERT! Energy consumption has exceeded the threshold of " + threshold + " kWh.");
        }
    }
}

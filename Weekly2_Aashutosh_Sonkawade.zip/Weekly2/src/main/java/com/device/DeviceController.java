package com.device;

import org.springframework.stereotype.Component;

@Component
public class DeviceController {
    private String deviceId;
    private String deviceName;
    private String status; 
        public DeviceController() {}

        public DeviceController(String deviceId, String deviceName) {
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.status = "OFF";    
        }

        public void turnOn() {
        status = "ON";
        System.out.println(deviceName + " is turned ON.");
    }

    public void turnOff() {
        status = "OFF";
        System.out.println(deviceName + " is turned OFF.");
    }

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}

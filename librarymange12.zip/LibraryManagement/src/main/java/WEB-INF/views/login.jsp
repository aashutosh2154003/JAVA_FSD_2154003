<html>
<head><title>Login</title></head>

<body>
	<h2>Please Login</h2>
	<form action="${pageContext.request.contextPath}/login" method="post">
		<label>Username: <input type="text" name="username"></label><br/>
		<label>Password: <input type="password" name="password"></label><br/>
		<button type="submit">Login</button>
	</form>
</body>
</html>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<html>
 <head><title>Books</title></head>
 <body>
 	<h2>Books</h2>
 	<table border=1>
 		<tr>
 			<th>ID</th>
 			<th>Title</th>
 			<th>Author</th>
 		</tr>
 		<c:forEach var="book" items="${books}">
 			<tr>
 				<td>${book.id}</td>
 				<td>${book.title}</td>
 				<td><c:forEach var="author" items="${book.authors }">${author.name }<br/>
 					</c:forEach></td>
 			</tr>
 		</c:forEach>
 	</table>
 	<a href="${pageContext.request.contextPath}/ui/books/new">Add New Book</a>
 	
 </body>
</html>
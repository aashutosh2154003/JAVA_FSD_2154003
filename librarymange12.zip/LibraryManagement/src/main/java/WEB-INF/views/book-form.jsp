<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<html>
<head><title>Add Book</title></head>

<body>
	<h2>Add New Book</h2>
	
	<form action="${pageContext.request.contextPath}/ui/books" method="post">
		<!-- Book Title -->
		<label>Title: </label>
		<input type="text" name="title" required/>
		<br/><br/>
		
		<!-- Authors (Checkboxes for many-to-many) -->
		<label>Authors: </label><br/>
		<c:forEach var="author" items="${authors}">
				<input type="checkbox" name="authorIds" value="${author.id}"/> ${author.name} <br/>
		</c:forEach>
		<br/>

		<!-- Submit Button -->
		<button type="submit">Save</button>
	</form>
</body>
</html>
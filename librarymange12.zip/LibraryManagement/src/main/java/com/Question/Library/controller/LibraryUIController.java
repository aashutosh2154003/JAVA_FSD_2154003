package com.Question.Library.controller;

import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Question.Library.model.Author;
import com.Question.Library.model.Book;
import com.Question.Library.repository.AuthorRepository;
import com.Question.Library.repository.BookRepository;

import jakarta.transaction.Transactional;

@Controller
@RequestMapping("/ui")
public class LibraryUIController {
	private final BookRepository bookRepository;
	private final AuthorRepository authorRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(LibraryUIController.class);
	
	public LibraryUIController(BookRepository bookRepository, AuthorRepository authorRepository) {
		this.authorRepository = authorRepository;
		this.bookRepository = bookRepository;
	}
	
	@GetMapping("/books")
	public String listBooks(Model model) {
		model.addAttribute("books", bookRepository.findAll());
		return "books";
	}
	
	@GetMapping("/books/new")
	public String listBookForm(Model model) {
		model.addAttribute("books", new Book());
		model.addAttribute("authors",authorRepository.findAll());
		return "book-form";
	}
	
	@PostMapping("/books")
	@Transactional
	public String saveBook(@RequestParam String title, @RequestParam(required=true) List<Long> authorIds) {
		// Step 1 : Save book first
		// To Optimize
		Book book = new Book();
		book.setTitle(title);
		bookRepository.save(book);
		
		// book now has an ID
		// Step 2 : Link authors
		if(authorIds != null && !authorIds.isEmpty()) {
			List<Author> authors = authorRepository.findAllById(authorIds);
			
			// Update both side if bidirectional
			for(Author author: authors) {
				author.getBooks().add(book);
			}
			book.setAuthors(new HashSet<>(authors));
		}
		
		// Save again to persist join table
		bookRepository.save(book);
		return "redirect:/ui/books";
	}
}

package com.Question.Library.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Question.Library.model.Author;

public interface AuthorRepository extends JpaRepository<Author, Long>{
	boolean existsByName(String name);
}

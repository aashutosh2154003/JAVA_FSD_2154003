package com.Question.Library.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean 
	public SecurityFilterChain SecurityFilerChain(HttpSecurity http)throws Exception {
		http
		.csrf(csrf -> csrf.disable())
		
		// Authorization rules
		.authorizeHttpRequests(auth -> auth
			.requestMatchers("/ui/books/new","/ui/authors/new").hasRole("ADMIN")
			.requestMatchers("/ui/**").authenticated()
			.anyRequest().permitAll()
		)
		
		// Custom login page
		.formLogin(form -> form
			.loginPage("/login")
			.defaultSuccessUrl("/ui/books",true)
			.permitAll()
		)
		
		.logout(logout -> logout
			.logoutSuccessUrl("/login?logout")
			.permitAll()
		);
		
		return http.build();
	}
}

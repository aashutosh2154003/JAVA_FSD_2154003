package com.Question.Library.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Question.Library.model.AppUser;

public interface UserRepository extends JpaRepository<AppUser ,Long>{
	AppUser findByUsername(String username);
}

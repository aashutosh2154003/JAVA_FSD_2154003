package com.Question.Library.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="authors")
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, unique=true)
	private String name;
	
	@ManyToMany(mappedBy="authors")
	@JsonIgnore
	private Set<Book> books = new HashSet<>();
	
	public Author() {}
	public Author(String name) {this.name = name;}
	
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public Set<Book> getBooks() {
		return books;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	
	@Override
	public boolean equals(Object o) {
		if(this == o) return true;
		
		if(!(o instanceof Author)) return false;
		Author author = (Author)o;
		return Objects.equals(id,author.id);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
}


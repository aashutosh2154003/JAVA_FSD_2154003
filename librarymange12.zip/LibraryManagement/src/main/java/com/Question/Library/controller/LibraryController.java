package com.Question.Library.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Question.Library.model.Author;
import com.Question.Library.model.Book;
import com.Question.Library.service.LibraryService;

@RestController
@RequestMapping("/library")
public class LibraryController {
	private final LibraryService service;
	
	public LibraryController(LibraryService service) {
		this.service = service;
	}
	
	@PostMapping("/cauthors")
	public Author createAuthor(@RequestParam String name) {
		return service.createAuthor(name);
	}
	
	@PostMapping("/cbooks")
	public Book createBook(@RequestParam String title) {
		return service.createBook(title);
	}
	
	@PostMapping("/books/{bookId}/authors/{authorId}")
	public Book LinkAuthor(@PathVariable Long bookId, @PathVariable Long authorId) {
		return service.linkAuthorToBook(bookId, authorId);
	}
	
	@GetMapping("/books")
	public List<Book> getBooks(){
		return service.getBooks();
	}
	
	@GetMapping("/authors")
	public List<Author> getAuthors(){
		return service.getAuthors();
	}
}

package com.Question.Library.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	
	@GetMapping("/login")
	public String loginPage() {
		// returns logical vier name "login"
		// Spring resolves this to /WEB-INF/views/login.jsp
		return "login";
	}
}

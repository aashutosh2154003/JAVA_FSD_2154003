package com.Question.Library.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Question.Library.model.Book;

public interface BookRepository extends JpaRepository<Book, Long>{
	boolean existsByTitle(String title);
}
